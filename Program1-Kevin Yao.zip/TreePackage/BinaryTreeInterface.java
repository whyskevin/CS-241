/***************************************************************
 * file: BinaryTreeInterface.java
 * author: T. Diaz
 * class: CS 241 – Data Structures II
 *
 * assignment: Program 1
 * date last modified: 10/16/2017
 *
 * purpose: Interface that defines methods that are used in BinaryTree
 ****************************************************************/ 
package TreePackage;

public interface BinaryTreeInterface<T>
extends TreeInterface<T>, TreeIteratorInterface<T>
{
	//method:setTree(T rootData)
	//purpose:Assigns data to the private variable
	public void setTree(T rootData);

	//method:setTree(T rootData, BinaryTreeInterface<T> leftTree,BinaryTreeInterface<T> rightTree)
	//purpose:Calls private method to set left and right child of a tree
	public void setTree(T rootData, BinaryTreeInterface<T> leftTree,
			BinaryTreeInterface<T> rightTree);
}