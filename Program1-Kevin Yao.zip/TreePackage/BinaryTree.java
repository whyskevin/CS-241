/***************************************************************
 * file: BinaryTree.java
 * author: T. Diaz
 * class: CS 241 – Data Structures II
 *
 * assignment: Program 1
 * date last modified: 10/16/2017
 *
 * purpose: BinaryTree implements BinaryTreeInterface. Constructs a binary tree that forms the base for the BST
 ****************************************************************/ 
package TreePackage;
import java.util.Iterator;
import java.util.Stack;
import java.util.NoSuchElementException;
//import StackAndQueuePackage.*; // needed by tree iterators


public class BinaryTree<T> implements BinaryTreeInterface<T>
{
	//Private variables
	private BinaryNodeInterface<T> root;

	//Constructors
	//method: BinaryTree()
	//purpose: Default constructor
	public BinaryTree()
	{
		root = null;
	} // end default constructor

	//method:BinaryTree(T rootData)
	//purpose:Constructor that assigns a new root
	public BinaryTree(T rootData)
	{
		root = new BinaryNode<T>(rootData);
	} // end constructor

	//method:BinaryTree(T rootData, BinaryTree<T> leftTree,	BinaryTree<T> rightTree)
	//purpose:Calls private method to set root of the tree
	public BinaryTree(T rootData, BinaryTree<T> leftTree,
			BinaryTree<T> rightTree)
	{
		privateSetTree(rootData, leftTree, rightTree);
	} // end constructor

	//method:setTree(T rootData)
	//purpose:Assigns data to the private variable
	public void setTree(T rootData)
	{
		root = new BinaryNode<T>(rootData);
	} // end setTree

	//method:setTree(T rootData, BinaryTreeInterface<T> leftTree,BinaryTreeInterface<T> rightTree)
	//purpose:Calls private method to set left and right child of a tree
	public void setTree(T rootData, BinaryTreeInterface<T> leftTree,
			BinaryTreeInterface<T> rightTree)
	{
		privateSetTree(rootData, (BinaryTree<T>)leftTree,
				(BinaryTree<T>)rightTree);
	} // end setTree

	//method:privateSetTree(T rootData, BinaryTree<T> leftTree,	BinaryTree<T> rightTree)
	//purpose:Calls private method to set left and right child of a tree
	private void privateSetTree(T rootData, BinaryTree<T> leftTree,
			BinaryTree<T> rightTree)
	{
		root = new BinaryNode<T>(rootData);
		if ((leftTree != null) && !leftTree.isEmpty())
			root.setLeftChild(leftTree.root);
		if ((rightTree != null) && !rightTree.isEmpty())
		{
			if (rightTree != leftTree)
				root.setRightChild(rightTree.root);
			else
				root.setRightChild(rightTree.root.copy());
		} // end if
		if ((leftTree != null) && (leftTree != this))
			leftTree.clear();
		if ((rightTree != null) && (rightTree != this))
			rightTree.clear();
	} // end privateSetTree


	//Accessor and Mutator
	//method: getRootData()
	//purpose:Returns root data if root is not null
	public T getRootData() {
		T rootData = null;
		if (root != null)
			rootData = root.getData();
		return rootData;	
	}

	//method: clear()
	//purpose:Assigns to root to null
	public void clear() {
		root = null;
	}

	//method: isEmpty()
	//purpose: Returns true if the root doesn't possess data
	public boolean isEmpty() {
		return root == null;
	}

	//method:getHeight()
	//purpose:Returns the height of the tree given the root
	public int getHeight() {
		return root.getHeight();
	}

	//method:getNumberOfNodes()
	//purpose:Return number of nodes
	public int getNumberOfNodes() {
		return root.getNumberOfNodes();
	}

	//method:setRootData(T rootData)
	//purpose:Protected method that assigns the root data
	protected void setRootData(T rootData)
	{
		root.setData(rootData);
	} // end setRootData

	//method:setRootNode()
	//purpose:Given a rootNode parameter, assigns it to the root
	protected void setRootNode(BinaryNodeInterface<T> rootNode)
	{
		root = rootNode;
	} // end setRootNode

	//method:getRootNode()
	//purpose:Retrieves the root of a BinaryTree
	protected BinaryNodeInterface<T> getRootNode()
	{
		return root;
	}// end getRootNode


	//Iterations
	//Iterative Inorder traversal


	public Iterator<T> getPreorderIterator() {
		// TODO Auto-generated method stub
		return null;
	}
	public Iterator<T> getPostorderIterator() {
		// TODO Auto-generated method stub
		return null;
	}
	public Iterator<T> getInorderIterator() {
		return new InorderIterator();
	}
	public Iterator<T> getLevelOrderIterator() {
		// TODO Auto-generated method stub
		return null;
	}

	//method: InorderIterator
	//purpose: Implements a recursive implementation that traverses a tree using a stack
	private class InorderIterator implements Iterator<T>{
		private Stack<BinaryNode<T> > traversalStack;
		private BinaryNode<T> currentNode;

		public InorderIterator(){
			traversalStack = new Stack<BinaryNode<T>> ();
			currentNode = (BinaryNode<T>) root;
		}

		public boolean hasNext() {
			return !traversalStack.isEmpty() || (currentNode == null);
		}

		public T next() {
			BinaryNode<T> nextNode = null;
			while(currentNode != null){
				traversalStack.push(currentNode);
				currentNode = (BinaryNode<T>) currentNode.getLeftChild();
			}
			if(!traversalStack.isEmpty()){
				nextNode = traversalStack.pop();
				assert nextNode != null;
				currentNode = (BinaryNode<T>)nextNode.getRightChild();
			}else{
				throw new NoSuchElementException();
			}
			return nextNode.getData();
		}
	}


	//Recursive Traversals
	//method: inorderTraverse()
	//purpose: Calls inorderTraverse function
	public void inorderTraverse()
	{
		inorderTraverse(root);
		System.out.println("");
	} // end inorderTraverse

	//method: inorderTraverse(BinaryNodeInterface<T> node)
	//purpose: Recursive method where a traversal is done be visiting different paths of a node. Left -> Data -> Right for inorder.
	private void inorderTraverse(BinaryNodeInterface<T> node)
	{
		if (node != null)
		{
			inorderTraverse(node.getLeftChild());
			System.out.print(node.getData() + " ");
			inorderTraverse(node.getRightChild());
		} // end if
	} // end inorderTraverse


	//method: preorderTraverse
	//purpose:Calls preorderTraverse method
	public void preorderTraverse(){
		preorderTraverse(root);
		System.out.println("");

	}

	//method: preorderTraverse(BinaryNodeInterface<T> node)
	//purpose: Recursive method where a traversal is done be visiting different paths of a node. Data -> Left -> Right for preorder.
	private void preorderTraverse(BinaryNodeInterface<T> node){
		if(node != null){
			System.out.print(node.getData() + " ");
			preorderTraverse(node.getLeftChild());
			preorderTraverse(node.getRightChild());
		}	
	}

	//method: postorderTraverse()
	//purpose: Calls postorder traverse function
	public void postorderTraverse(){
		postorderTraverse(root);
		System.out.println("");

	}

	//method: postorderTraverse(BinaryNodeInterface<T> node)
	//purpose: Recursive method where a traversal is done be visiting different paths of a node. Left -> Right -> Data for postorder.
	private void postorderTraverse(BinaryNodeInterface<T> node){
		if(node != null){
			postorderTraverse(node.getLeftChild());
			postorderTraverse(node.getRightChild());
			System.out.print(node.getData() + " ");
		}	
	}

	//method:print(BinaryNodeInterface<T> root, int level)
	//purpose:Uses recursion and tree height to print a binary tree horizontally
	public void print(BinaryNodeInterface<T> root, int level){
		if(root.getRightChild() != null){
			print(root.getRightChild(), level + 1);
		}
		int spaces = level * 4;
		for(int i = 0; i < spaces; i++){
			System.out.print(" ");
		}
		System.out.println(root.getData());
		if(root.getLeftChild() != null){
			print(root.getLeftChild(), level + 1);
		}
	}


}