/***************************************************************
 * file: TreeInterface.java
 * author: T. Diaz
 * class: CS 241 – Data Structures II
 *
 * assignment: Program 1
 * date last modified: 10/16/2017
 *
 * purpose: Program interface that defines the methods used with generic trees
 ****************************************************************/ package TreePackage;

 public interface TreeInterface<T>
 {
	 //method: getRootData()
	 //purpose: Returns root data
	 public T getRootData();
	 
	 //method:getHeight()
	 //purpose: Returns the height of a generic tree
	 public int getHeight();
	 
	 //method:getNumberOfNodes
	 //purpose: Returns the number of nodes that exist within a tree
	 public int getNumberOfNodes();
	 
	 //method:isEmpty
	 //purpose:Returns true if the tree has no data/children
	 public boolean isEmpty();
	 
	 //method:clear()
	 //purpose:Sets the root to null, deallocating the tree's data
	 public void clear();
	 
 } // end TreeInterface

