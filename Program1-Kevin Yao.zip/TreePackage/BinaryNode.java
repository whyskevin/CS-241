/***************************************************************
 * file: BinaryNode.java
 * author: T. Diaz
 * class: CS 241 – Data Structures II
 *
 * assignment: Program 1
 * date last modified: 10/16/2017
 *
 * purpose: This program implements the BinaryNodeInterface and defines the BinaryNode.
 *  This object is used in the construction of a BinaryTree and BinarySearchTree.
 *
 ****************************************************************/ 
package TreePackage;

public class BinaryNode<T> implements BinaryNodeInterface<T> {
	//Private variables
	private T data;
	private BinaryNode<T> left;
	private BinaryNode<T> right;

	//method:BinaryNode()
	//purpose:Constructor to create an empty instance of a BinaryNode
	public BinaryNode()
	{
		this(null); // call next constructor
	}
	
	//method:BinaryNode(T dataPortion)
	//purpose:Constructor that takes T dataPortion and calls another constructor
	public BinaryNode(T dataPortion)
	{
		this(dataPortion, null, null); // call next constructor
	}
	
	//method:BinaryNode(T dataPortion, BinaryNode<T> leftChild,	BinaryNode<T> rightChild)
	//purpose:Constructor takes data, a left and right BinaryNode. Assigns it to BinaryNode private variables
	public BinaryNode(T dataPortion, BinaryNode<T> leftChild,
			BinaryNode<T> rightChild)
	{
		data = dataPortion;
		left = leftChild;
		right = rightChild;
	} 

	//method:getData()
	//purpose:Returns the T data
	public T getData() {
		return data;
	}

	//method:setData(T newData)
	//purpose:Assigns new data to the private variable
	public void setData(T newData) {
		data = newData;
	}

	//method:getLeftChild()
	//purpose:Returns left child
	public BinaryNodeInterface<T> getLeftChild() {
		return left;
	}

	//method:getRightChild()
	//purpose:Returns right child
	public BinaryNodeInterface<T> getRightChild() {
		return right;
	}

	//method:setLeftChild(BinaryNodeInterface<T> leftChild)
	//purpose:Casts and assigns a leftChild
	public void setLeftChild(BinaryNodeInterface<T> leftChild) {
		left = (BinaryNode <T>)leftChild;
	}

	//method:setRightChild(BinaryNodeInterface<T> rightChild)
	//purpose:Casts and assigns a rightChild
	public void setRightChild(BinaryNodeInterface<T> rightChild) {
		right = (BinaryNode <T>) rightChild;
	}

	//method:hasLeftChild() 
	//purpose: returns true if leftChild exists
	public boolean hasLeftChild() {
		return (left != null);
	}

	//method:hasRightChild()
	//purpose: returns right if rightChild exists
	public boolean hasRightChild() {
		return (right != null);
	}

	//method:isLeaf()
	//purpose: returns true if BinaryNode is a leaf
	public boolean isLeaf() {
		return (left == null) && (right == null);	
	}

	//method:getNumberOfNodes()
	//purpose:If left/right child exists, uses recursion to calculate tree height
	public int getNumberOfNodes()
	{
		int leftNumber = 0;
		int rightNumber = 0;
		if (left != null)
			leftNumber = left.getNumberOfNodes();
		if (right != null)
			rightNumber = right.getNumberOfNodes();
		return 1 + leftNumber + rightNumber;
	} // end getNumberOfNodes

	
	//method:getHeight()
	//purpose:Calls a private getHeight()
	public int getHeight()
	{
		return getHeight(this); // call private getHeight
	} // end getHeight

	//method:getHeight(BinaryNode<T> node)
	//purpose:Private helper function that calculates a tree's height using recursion
	private int getHeight(BinaryNode<T> node)
	{
		int height = 0;
		if (node != null)
			height = 1 + Math.max(getHeight(node.left),
					getHeight(node.right));
		return height;
	} // end getHeight

	//method:BinaryNodeInterface<T> copy()
	//purpose:Travels down a tree and recursively copies all BinaryNodes
	public BinaryNodeInterface<T> copy()
	{
		BinaryNode<T> newRoot = new BinaryNode<T>(data);
		if (left != null)
			newRoot.left = (BinaryNode<T>)left.copy();
		if (right != null)
			newRoot.right = (BinaryNode<T>)right.copy();
		return newRoot;
	} // end copy

}
