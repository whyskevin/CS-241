/***************************************************************
 * file: BinarySearchTree.java
 * author: T. Diaz
 * class: CS 241 – Data Structures II
 *
 * assignment: Program 1
 * date last modified: 10/16/2017
 *
 * purpose: This program implements SearchTreeInterface and extends Comparable superclass and BinaryTree
 ****************************************************************/ 
package TreePackage;
import java.util.Iterator;

public class BinarySearchTree<T extends Comparable<? super T>> 
extends BinaryTree<T>
implements SearchTreeInterface<T>

{
	//method:BinarySearchTree()
	//purpose: Default constructor. Calls superclass constructor
	public BinarySearchTree()
	{
		super();
	} // end default constructor

	//method:BinarySearchTree(T rootEntry)
	//purpose:Constructor calls superclass and sets the root data
	public BinarySearchTree(T rootEntry)
	{
		super();
		setRootNode(new BinaryNode<T>(rootEntry));
	} // end constructor

	//method:setTree(T rootData)
	//purpose:Unused method because we use the BinaryTree setTree method
	public void setTree(T rootData)
	{
		throw new UnsupportedOperationException();
	} // end setTree

	//method: setTree(T rootData, BinaryTreeInterface<T> leftTree, BinaryTreeInterface<T> rightTree)
	//purpose:Unused method because we use the BinaryTree setTree method
	public void setTree(T rootData, BinaryTreeInterface<T> leftTree,
			BinaryTreeInterface<T> rightTree)
	{
		throw new UnsupportedOperationException();
	} // end setTree

	//SearchTreeInterface Methods

	//method: contains(T entry)
	//purpose: Returns true if the entry exists
	public boolean contains(T entry) {
		return getEntry(entry) != null;
	}

	//method:getEntry(T entry)
	//purpose:Calls the private findEntry method
	public T getEntry(T entry)
	{
		return findEntry(getRootNode(), entry);
	} // end getEntry

	//method:findEntry(BinaryNodeInterface<T> rootNode, T entry)
	//purpose:Looks for an entry. Returns the data if found and null if it DNE
	private T findEntry(BinaryNodeInterface<T> rootNode, T entry)
	{
		T result = null;
		if (rootNode != null)
		{
			T rootEntry = rootNode.getData();
			if (entry.equals(rootEntry))
				result = rootEntry;
			else if (entry.compareTo(rootEntry) < 0)
				result = findEntry(rootNode.getLeftChild(), entry);
			else
				result = findEntry(rootNode.getRightChild(), entry);
		} // end if
		return result;
	} // end findEntry

	//method:returnNode(BinaryNodeInterface<T> rootNode, T findMe)
	//purpose:Returns a node where a T data resides.
	private BinaryNodeInterface<T> returnNode(BinaryNodeInterface<T> rootNode, T findMe){
		if(rootNode != null){
			int comparison = findMe.compareTo(rootNode.getData());
			if(comparison == 0){ //If the node's data is equal to T findMe
				return rootNode;
			}else if (comparison < 0){ //findMe is smaller than what is at rootNode 
				if(rootNode.hasLeftChild()){
					returnNode(rootNode.getLeftChild(), findMe);
				}
			}else{
				if(rootNode.hasRightChild()){
					returnNode(rootNode.getRightChild(), findMe);
				}
			}
		}
		return rootNode;
	}

	//method: add(T newEntry)
	//purpose: Adds a newEntry to the tree, calls addEntry function which inserts into the tree
	public T add(T newEntry) {
		T result = null;
		if (isEmpty())
			setRootNode(new BinaryNode<T>(newEntry));
		else
			result = addEntry(getRootNode(), newEntry);
		return result;	}


	//method: addEntry(BinaryNodeInterface<T> rootNode, T newEntry)
	//purpose:Traverses through the tree with recursion to find the place to insert newEntry
	private T addEntry(BinaryNodeInterface<T> rootNode, T newEntry)
	{
		assert rootNode != null;
		T result = null;
		int comparison = newEntry.compareTo(rootNode.getData());
		if (comparison == 0)
		{
			result = rootNode.getData();
			rootNode.setData(newEntry);
			System.out.println(newEntry + " already exists, ignore.");
		}
		else if (comparison < 0)
		{
			if (rootNode.hasLeftChild())
				result = addEntry(rootNode.getLeftChild(), newEntry);
			else
				rootNode.setLeftChild(new BinaryNode<T>(newEntry));
		}
		else
		{
			assert comparison > 0;
			if (rootNode.hasRightChild())
				result = addEntry(rootNode.getRightChild(), newEntry);
			else
				rootNode.setRightChild(new BinaryNode<T>(newEntry));
		} // end if
		return result;
	} // end addEntry

	//method: remove(T entry)
	//purpose: Creates an empty BinaryNode. Calles the removeEntry method and reassigns the root node
	public T remove(T entry) {
		BinaryNode<T> returnObject = new BinaryNode<T>(null); //Creates an empty BinaryNode. Variable to return at the end of the function
		BinaryNodeInterface<T> newRoot = removeEntry(getRootNode(), entry, returnObject);
		setRootNode(newRoot); //Sets the newRoot
		return returnObject.getData();
	}

	//method:removeEntry(BinaryNodeInterface<T> rootNode, T entry, BinaryNode<T> oldEntry)
	//purpose:Traverses the tree with a recursive calls until the entry is found/not found.
	private BinaryNodeInterface<T> removeEntry(BinaryNodeInterface<T> rootNode, T entry, BinaryNode<T> oldEntry)
	{
		if (rootNode != null)
		{
			T rootData = rootNode.getData();
			int comparison = entry.compareTo(rootData);
			if (comparison == 0) // entry == root entry
			{
				//The object exists. 
				oldEntry.setData(rootData); //Preserves the node we want to remove
				rootNode = removeFromRoot(rootNode); //Reassigns the root with the predecessor/successor of the root we removed
			}
			else if (comparison < 0) // entry < root entry
			{
				BinaryNodeInterface<T> leftChild = rootNode.getLeftChild();
				BinaryNodeInterface<T> subtreeRoot = removeEntry(leftChild,
						entry, oldEntry);
				rootNode.setLeftChild(subtreeRoot);
			}
			else if(comparison > 0)// entry > root entry
			{
				BinaryNodeInterface<T> rightChild = rootNode.getRightChild();
				rootNode.setRightChild(removeEntry(rightChild, entry, oldEntry));
			} 
		}else{
			//If the item is not found, this recursive method will return null. Thus it breaks out of the if statement.
			System.out.println( entry.toString() + " doesn't exist!");
		}// end if// end if
		return rootNode;
	} // end removeEntry


	//method: removeFromRoot(BinaryNodeInterface<T> rootNode)
	//purpose:If the entry is found, removeFromRoot addresses the different cases given the node position
	private BinaryNodeInterface<T> removeFromRoot(BinaryNodeInterface<T> rootNode)
	{
		// Case 1: rootNode has two children
		if (rootNode.hasLeftChild() && rootNode.hasRightChild())
		{
			// find node with largest entry in left subtree
			BinaryNodeInterface<T> leftSubtreeRoot = rootNode.getLeftChild();
			BinaryNodeInterface<T> largestNode = findLargest(leftSubtreeRoot);
			// replace entry in root
			rootNode.setData(largestNode.getData());
			// remove node with largest entry in left subtree
			rootNode.setLeftChild(removeLargest(leftSubtreeRoot));
		} // end if
		// Case 2: rootNode has at most one child
		else if (rootNode.hasRightChild())
			rootNode = rootNode.getRightChild();
		else
			rootNode = rootNode.getLeftChild();
		// Assertion: if rootNode was a leaf, it is now null
		return rootNode;
	} // end removeEntry

	//method: findLargest(BinaryNodeInterface<T> rootNode)
	//purpose:Recursive call on a node's right subtree to return the largest value
	private BinaryNodeInterface<T> findLargest(BinaryNodeInterface<T> rootNode)
	{
		if (rootNode.hasRightChild())
			rootNode = findLargest(rootNode.getRightChild());
		return rootNode;
	} // end findLargest


	//method:removeLargest(BinaryNodeInterface<T> rootNode)
	//purpose: Removes the node containing the largest entry in a given tree.
	//rootNode is the root node of the tree.
	//Returns the root node of the revised tree.
	private BinaryNodeInterface<T> removeLargest(BinaryNodeInterface<T> rootNode)
	{
		if (rootNode.hasRightChild())
		{
			BinaryNodeInterface<T> rightChild = rootNode.getRightChild();
			BinaryNodeInterface<T> root = removeLargest(rightChild);
			rootNode.setRightChild(root);
		}
		else
			rootNode = rootNode.getLeftChild();
		return rootNode;
	} // end removeLargest


	//method: getMin()
	//purpose:Calls helper function to get the min value
	public T getMin() {
		return findMin(getRootNode());
	}

	//method:findMin( BinaryNodeInterface<T> root)
	//purpose:Recursive method that checks for the smallest value
	private T findMin( BinaryNodeInterface<T> root){
		if(root.isLeaf()){
			System.out.println("Min:" + root.getData());
			return root.getData();
		}else{
			if(root.hasLeftChild()){
				findMin(root.getLeftChild());
			}
		}
		return null;
	}

	//method: getMax()
	//purpose:Calls helper function to get the max value
	public T getMax() {
		return findMax(getRootNode());	
	}

	//method: findMax()
	//purpose:Recursive method that checks for the largest value
	private T findMax(BinaryNodeInterface<T> root){
		if(root.isLeaf()){
			System.out.println("Max:" + root.getData());
			return root.getData();
		}else{
			if(root.hasRightChild()){
				findMax(root.getRightChild());
			}
		}
		return null;	
	}

	//method: getPredecessor()
	//purpose:Uses an iterator to find the predecessor of an entry
	public T getPredecessor(T entry) {
		Iterator<T> it = getInorderIterator();
		T walker = it.next();
		T predecessor = walker;
//		System.out.println("Head:" + predecessor);
		while(walker != entry){
			predecessor = walker;
			//			System.out.println("IT:" + predecessor);
			walker = it.next();
		}
		System.out.println("Predecessor:" + predecessor);
		return predecessor;
	}

	//method: getSuccessor()
	//purpose:Uses an iterator to find the successor of an entry
	public T getSuccessor(T entry) {
		Iterator<T> it = getInorderIterator();
		T walker = it.next();
		T successor = walker;
//		System.out.println("Head:" + successor);
		while(walker != entry){
			//			System.out.println("IT:" + predecessor);
			walker = it.next();
		}
		successor = it.next();
		System.out.println("Successor:" + successor);
		return successor;
	}

}