/***************************************************************
 * file: BinaryNodeInterface.java
 * author: T. Diaz
 * class: CS 241 – Data Structures II
 *
 * assignment: Program 1
 * date last modified: 10/16/2017
 *
 * purpose: This program defines an interface that implements functions for the BinaryNode
 ****************************************************************/ 
package TreePackage;

interface BinaryNodeInterface<T>
{
	//method:getData()
	//purpose:Retrieves the data portion of this node.
	//Returns the object in the data portion of the node
	public T getData();

	//method:setData(T newData)
	//purpose:Sets the data portion of this node.
	//Returns newData the data object
	public void setData(T newData);

	//method:BinaryNodeInterface<T> getLeftChild();
	//purpose:Retrieves the left child of this node.
	//Returns the node that is this node’s left child */
	public BinaryNodeInterface<T> getLeftChild();

	//method: BinaryNodeInterface<T> getRightChild();
	//purpose:Retrieves the right child of this node.
	//Returns the node that is this node’s right child */
	public BinaryNodeInterface<T> getRightChild();

	//method:setLeftChild(BinaryNodeInterface<T> leftChild);
	//purpose:Sets this node’s left child to a given node.
	// Parameter is leftChild a node that will be the left child
	public void setLeftChild(BinaryNodeInterface<T> leftChild);

	//method:setRightChild(BinaryNodeInterface<T> rightChild);
	//purpose:Sets this node’s right child to a given node.
	//Parameter is rightChild a node that will be the right child
	public void setRightChild(BinaryNodeInterface<T> rightChild);

	//method:hasLeftChild()
	//purpose:Detects whether this node has a left child.
	//Returns true if the node has a left child
	public boolean hasLeftChild();

	//method:hasRightChild()
	//purpose:Detects whether this node has a right child.
	//Returns true if the node has a right child
	public boolean hasRightChild();

	//method:isLeaf()
	//purpose:Detects whether this node is a leaf.
	//Returns true if the node is a leaf
	public boolean isLeaf();

	//method:getNumberOfNodes()
	//purpose:Counts the nodes in the subtree rooted at this node.
	//Returns the number of nodes in the subtree rooted at this node
	public int getNumberOfNodes();

	//method:getHeight()
	//purpose:Computes the height of the subtree rooted at this node.
	//Returns the height of the subtree rooted at this node
	public int getHeight();

	//method:copy()
	//purpose:Copies the subtree rooted at this node.
	//Returns the root of a copy of the subtree rooted at this node
	public BinaryNodeInterface<T> copy();
	
} // end BinaryNodeInterface