/***************************************************************
 * file: Program1.java
 * author: T. Diaz
 * class: CS 241 – Data Structures II
 *
 * assignment: Program 1
 * date last modified: 10/16/2017
 *
 * purpose: Java file that contains the main method. Introduces the user interface and menu to manipulate a BST
 ****************************************************************/ 
package TreePackage;

import java.util.Scanner;

public class Program1 {

	//method: main()
	//purpose: Begins the program
	public static void main(String [] args){
		run();
	}

	//method:run()
	//purpose: Builds an user interface based on Program 1 specifications that allows an user to interact/manipulate a Binary Search Tree
	public static void run(){
		System.out.println("Please enter the initial sequence of values:");
		Scanner in = new Scanner(System.in);
		String initialValues = in.nextLine(); //Stores the initial sequence of values in a String
		Scanner parse = new Scanner(initialValues);

		//Creates an empty tree to receive the initialValues
		BinarySearchTree <Integer> tree = new BinarySearchTree <Integer> ();

		//Parses the input and checks if the input is valid
		while(parse.hasNext()){
			String token = parse.next(); //Extracts a string from the scanner
			if(isInteger(token)){ //True if token is an integer
				int addMe = Integer.parseInt(token);
				tree.add(addMe); //Adds to the tree if the input is valid
			}else{
				System.out.println("Values contain invalid input!");
				tree.clear();
				break;
			}
		}

		//Prints summary of all traversals
		System.out.print("Pre-order:");
		tree.preorderTraverse();
		System.out.print("In-order:");
		tree.inorderTraverse();		
		System.out.print("Post-order:");
		tree.postorderTraverse();


		//Prompts for another command
		System.out.print("Command? ");
		String command = in.nextLine();
		//		System.out.println("Command:" + command);
		while(command.charAt(0) != 'E' || command.charAt(0) != 'e'){	//Keeps prompting for a command until user inputs 'E' to exit
			Scanner forInteger = new Scanner(command);
			command = forInteger.next();
			//Determines the switch case given a command and a value
			int switchCase = commandValue(command);
			//			System.out.println("Switchcase:" + switchCase);
			int value = 0;
			//Grabs the value give along with the single character command
			if(forInteger.hasNextInt()){
				value = forInteger.nextInt();
			}			
			//			System.out.println("Value:" + value);
			switch(switchCase){
			case 0: //Handles all cases 
				exitProgram();
				break;
			case 1:
				tree.add(value);
				System.out.print("In-order:");
				tree.inorderTraverse();
				break;
			case 2:
				tree.remove(value);
				System.out.print("In-order:");
				tree.inorderTraverse();
				break;
			case 3:
				tree.getPredecessor(value);
				break;
			case 4:
				tree.getSuccessor(value);
				break;
			case 5: 
				displayHelpMessage();
				break;
			default:
				System.out.println("Invalid command!");
				break;
			}
			System.out.print("Command? ");
			command = in.nextLine();
		}
		//The first character becomes 'E' and therefore the program shall exit!
		in.close();
		parse.close();
		exitProgram();
	}


	//method:commandValue(String command)
	//purpose:Takes an String and determines the following commands by looking at the first character
	public static int commandValue(String command){
		command = command.toUpperCase();
		//		System.out.println("toupper:" + command); Testing
		char firstLetter = command.charAt(0);
		if(firstLetter == 'E'){
			return 0;
		}else 
			if(firstLetter == 'I'){
				return 1;
			}else if(firstLetter == 'D'){
				return 2;
			}else if(firstLetter == 'P'){
				return 3;
			}else if(firstLetter == 'S'){
				return 4;
			}else if(firstLetter == 'H'){
				return 5;
			}
		return 0;
	}


	//method: exitProgram()
	//purpose:Displays end message and exits the program
	public static void exitProgram(){
		System.out.println("Thank you for using my program!");
		System.exit(0);
	}

	//method: displayHelpMessage()
	//purpose:Displays the series of commands that are possible when prompted
	public static void displayHelpMessage(){
		System.out.println(" I Insert a value");
		System.out.println(" D Delete a value");
		System.out.println(" P Find predecessor");
		System.out.println(" S Find successor");
		System.out.println(" E Exit the program");
		System.out.println(" H Display this message");
	}

	//method: isInteger(String input)
	//purpose:Given a String parameter, checks if the String can be converted into an Integer value
	public static boolean isInteger(String input){
		try{
			Integer.parseInt(input);
			return true;
		}catch (NumberFormatException e) {
			return false;
		}
	}

}
