/***************************************************************
 * file: TreeIteratorInterface.java
 * author: T. Diaz
 * class: CS 241 – Data Structures II
 *
 * assignment: Program 1
 * date last modified: 10/16/2017
 *
 * purpose: Interface that defines the methods used with tree iterators
 ****************************************************************/ package TreePackage;

import java.util.Iterator;
public interface TreeIteratorInterface<T>
{
	public Iterator<T> getPreorderIterator();
	public Iterator<T> getPostorderIterator();
	public Iterator<T> getInorderIterator();
	public Iterator<T> getLevelOrderIterator();
} // end TreeIteratorInterface  