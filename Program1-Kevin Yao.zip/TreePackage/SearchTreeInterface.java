/***************************************************************
 * file: SearchTreeInterface.java
 * author: T. Diaz
 * class: CS 241 – Data Structures II
 *
 * assignment: Program 1
 * date last modified: 10/16/2017
 *
 * purpose: Program defines the methods used with BinarySearchTree
 ****************************************************************/ package TreePackage;
import java.util.Iterator;

public interface SearchTreeInterface<T extends Comparable<? super T>>
extends TreeInterface<T>
{
	/** Searches for a specific entry in this tree.
@param entry an object to be found
@return true if the object was found in the tree */
	public boolean contains(T entry);
	/** Retrieves a specific entry in this tree.
@param entry an object to be found
@return either the object that was found in the tree or
null if no such object exists */
	public T getEntry(T entry);
	/** Adds a new entry to this tree.
If the entry matches an object that exists in the tree
already, replaces the object with the new entry.
@param newEntry an object to be added to the tree
@return either null if newEntry was not in the tree already, or
an existing entry that matched the parameter newEntry
and has been replaced in the tree */
	public T add(T newEntry);
	/** Removes a specific entry from this tree.
@param entry an object to be removed
@return either the object that was removed from the tree or
null if no such object exists */
	public T remove(T entry);
	/** Creates an iterator that traverses all entries in this tree.
@return an iterator that provides sequential and ordered access
to the entries in the tree */
	public Iterator<T> getInorderIterator();



	/** @return the entry with the smallest search key */
	public T getMin();
	/** @return the entry with the largest search key */
	public T getMax();
	/** @return either the inorder predecessor of entry, or
	entry if it’s the smallest element in the tree, or
	null if entry is not in the tree */
	public T getPredecessor(T entry);
	/** @return either the inorder successor of entry, or
	entry if it’s the largest element in the tree, or
	null if entry is not in the tree */
	public T getSuccessor(T entry);


} // end SearchTreeInterface

