/***************************************************************
* file: MaxHeapInterface.java
* author: T. Diaz
* class: CS 241 – Data Structures II
*
* assignment: Program 2
* date last modified: 10/30/17
*
* purpose: This program is an interface that declares the methods for a MaxHeap.
*
****************************************************************/ 
package MaxHeap;
public interface MaxHeapInterface<T extends Comparable<? super T>>
{
	public void add(T newEntry);
	public T removeMax();
	public T getMax();
	public boolean isEmpty();
	public int getSize();
	public void clear();
} // end MaxHeapInterface