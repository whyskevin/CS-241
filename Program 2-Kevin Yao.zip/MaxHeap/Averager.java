/***************************************************************
* file: Averager.java
* author: T. Diaz
* class: CS 241 – Data Structures II
*
* assignment: Program 2
* date last modified: 10/30/17
*
* purpose: This program takes in integer values and averages the values with integer division.
*
****************************************************************/ 
package MaxHeap;

public class Averager {

	private int numberOfValues;
	private int valueSum;

	//method: Averager()
	//purpose: Default constructor. Defines private variables
	public Averager(){
		numberOfValues = 0;
		valueSum = 0;
	}
	
	//method: insertValue(int val)
	//purpose: Adds the presented value and sums it
	public void insertValue(int val){
		valueSum = valueSum + val;
		numberOfValues++;
	}

	//method: returnAverage()
	//purpose: Calculates the average of all values appended. Integer division gives us the floor of the result
	public int returnAverage(){
		return (valueSum/numberOfValues);
	}

	//method: clear()
	//purpose: Resets the averager so that it may be used again.
	public void clear(){
		numberOfValues = 0;
		valueSum = 0;
	}

}
