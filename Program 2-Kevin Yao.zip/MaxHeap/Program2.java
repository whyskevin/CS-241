/***************************************************************
* file: Program2.java
* author: T. Diaz
* class: CS 241 – Data Structures II
*
* assignment: Program 2
* date last modified: 10/30/17
*
* purpose: This program takes user input and generates two MaxHeaps. Each MaxHeap is created using a different insertion method.
* Case 1 addresses the chronological insertion method while Case 2 uses the optimal method with an array of values
*
****************************************************************/ 
package MaxHeap;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Random;
import java.util.Scanner;
import java.util.Set;

public class Program2 {
	
	//method: main()
	//purpose: Holds a switch case that calls two other methods: Case 1 and Case 2
	public static void main(String[] args){

		System.out.print(
				"Please select how to test the program:\n"+
						"(1) 20 sets of 100 randomly generated integers\n"+
						"(2) Fixed integer values 1-100\n"+
				"Enter choice: ");
		Scanner in = new Scanner(System.in);
		int choice = in.nextInt();
		switch(choice){
		case 1:
			choiceOne();
			break;
		case 2:
			choiceTwo();
			break;
		default:
			break;
		}
	}

	//method: choiceOne()
	//purpose: Creates 20 sets of 100 random integers between [1,100]. Then it displays the number of times the MaxHeap swaps
	public static void choiceOne(){
		Averager insertionMethod = new Averager();
		Averager optimalMethod = new Averager();
		Integer sets [][] = new Integer[20][100]; //Create 2D array
		int j = 0;
		for(int i = 0; i < 20; i++){
			MaxHeap <Integer> insertion = new MaxHeap<Integer>();
			Set <Integer> integerSet = returnRandom();
			Iterator<Integer> it = integerSet.iterator();
			while(it.hasNext()){
//				System.out.println("J" + j + " - It:" + it.next()); //DON'T CALL IT.NEXT() MORE THAN ONCE
				sets[i][j] = it.next();
				insertion.add(sets[i][j]);
				j++;
//				System.out.println("sets["+ i + "]["+ j +"]" + sets[i][j]);
			}
			insertionMethod.insertValue(insertion.numberOfSwaps());
			MaxHeap<Integer> optimal = new MaxHeap<Integer>(sets[i]);
			optimalMethod.insertValue(optimal.numberOfSwaps());
			j = 0; //Reset
//			System.out.println("----------------------");
		}
		System.out.println("\nAverage swaps for series of insertions: "+ insertionMethod.returnAverage());
		System.out.println("Average swaps for optimal method: " + optimalMethod.returnAverage());
	}

	//method: returnRandom()
	//purpose: Using Random, this  method generates random integers. Using a LinkedHashSet, we get 100 unique positive, random #s
	//These integers will be passed into the array in choiceOne() and then added to the MaxHeap
	public static Set<Integer> returnRandom(){
		Random rand = new Random();
		Set <Integer> set = new LinkedHashSet<Integer>(); //Use a LinkedHashSet to keep values unique and to preserve the order
		//We then generate random numbers and add them to the set to keep uniqueness
		do{
			int temp = rand.nextInt(100) + 1;//Plus 1 because we don't want 0 as a value
			set.add(temp);
//			System.out.println(temp +" - SetSize:" + set.size());
		}while(set.size() < 100);
//		System.out.println("SET SIZE:" + set.size());
		//At this point our set contains 100 random positive integers [1,100]
		return set;
	}

	
	//method: choiceTwo()
	//purpose: Inserts positive integers [1,100] into a MaxHeap using insertion and optimal methods.
	//We then compare and display a summary of the # of swaps used per method
	public static void choiceTwo(){
		MaxHeap<Integer> insertion = new MaxHeap<Integer>();
		Integer hundredIntegers [] = new Integer[100];
		for(int i = 0; i < 100; i++){
			hundredIntegers[i] = i+1;
			insertion.add(hundredIntegers[i]); //Insertion method
		}
		MaxHeap<Integer> optimal = new MaxHeap<Integer>(hundredIntegers); //Initialize this MaxHeap with the optimal method
		System.out.print("\nHeap built using series of insertions:");
		insertion.printHeap();
		System.out.print("Number of swaps: " + insertion.numberOfSwaps() );
		for(int j = 0; j < 10; j++){
			insertion.removeMax();
		}
		System.out.print("\nHeap after 10 removals:");
		insertion.printHeap();
		System.out.print("\nHeap built using optimal method:");
		optimal.printHeap();
		System.out.print("Number of swaps: "+optimal.numberOfSwaps());
		for(int j = 0; j < 10; j++){
			optimal.removeMax();
		}
		System.out.print("\nHeap after 10 removals:");
		optimal.printHeap();
	}
}

