/***************************************************************
 * file: MaxHeap.java
 * author: T. Diaz
 * class: CS 241 – Data Structures II
 *
 * assignment: Program 2
 * date last modified: 10/30/17
 *
 * purpose: This program implements the MaxHeapInterface and defines the methods that build a MaxHeap.
 * Uses an array to implement the MaxHeap.
 *
 ****************************************************************/ 
package MaxHeap;
import java.util.Arrays;

public class MaxHeap<T extends Comparable<? super T>>
implements MaxHeapInterface<T>
{
	private T[] heap; // array of heap entries
	private int lastIndex; // index of last entry
	private int swapAmount; //Holds the number of reheaps the heap performs
	private static final int DEFAULT_INITIAL_CAPACITY = 25;

	//method: MaxHeap()
	//purpose: Default constructor for MaxHeap
	public MaxHeap()
	{
		this(DEFAULT_INITIAL_CAPACITY); // call next constructor
	} // end default constructor

	//method: MaxHeap(int initialCapacity)
	//purpose: Constructor for MaxHeap that takes a value for the MaxHeap size
	public MaxHeap(int initialCapacity)
	{
		// the cast is safe because the new array contains all null entries
		@SuppressWarnings("unchecked")
		T[] tempHeap = (T[]) new Comparable[initialCapacity + 1];
		heap = tempHeap;
		lastIndex = 0;
	} // end constructor

	//method: MaxHeap(T[] entries)
	//purpose: Constructor for MaxHeap which takes an array of values. Used for optimal method
	public MaxHeap(T[] entries)
	{
		// the cast is safe because the new array contains null entries
		@SuppressWarnings("unchecked")
		T[] tempHeap = (T[]) new Comparable[entries.length + 1];
		heap = tempHeap;
		lastIndex = entries.length;
		// copy given array to data field
		for (int index = 0; index < entries.length; index++)
			heap[index + 1] = entries[index];
		// create heap
		for (int rootIndex = lastIndex / 2; rootIndex > 0; rootIndex--)
			reheap(rootIndex);
	} // end constructor

	//method: getMax()
	//purpose: Returns the largest value in a MaxHeap. It should always be at the first index
	public T getMax()
	{
		T root = null;
		if (!isEmpty())
			root = heap[1];
		return root;
	} // end getMax

	//method: isEmpty()
	//purpose: Returns true if the MaxHeap contains no elements
	public boolean isEmpty()
	{
		return lastIndex < 1;
	} // end isEmpty

	//method: getSize()
	//purpose: Returns the size of the MaxHeap
	public int getSize()
	{
		return lastIndex;
	} // end getSize

	//method: clear()
	//purpose: Dereferences all elements of the MaxHeap
	public void clear()
	{
		for (; lastIndex > -1; lastIndex--)
			heap[lastIndex] = null;
		lastIndex = 0;
	} // end clear

	//method: ensureCapacity()
	//purpose: If the number of elements within the MaxHeap begin to exceed the size of the array
	//this method will copy the array into another twice its size
	private void ensureCapacity()
	{
		if (lastIndex >= heap.length)
			heap = Arrays.copyOf(heap, 2 * heap.length);
	}

	//method: reheap()
	//purpose: Given an element, compare with parent. If larger or smaller, we swap the indices and reassign the element.
	private void reheap(int rootIndex)
	{
		boolean done = false;
		T orphan = heap[rootIndex];
		int leftChildIndex = 2 * rootIndex;
		while (!done && (leftChildIndex <= lastIndex) )
		{
			int largerChildIndex = leftChildIndex; // assume larger
			int rightChildIndex = leftChildIndex + 1;
			if ( (rightChildIndex <= lastIndex) &&
					heap[rightChildIndex].compareTo(heap[largerChildIndex]) > 0)
			{
				largerChildIndex = rightChildIndex;
			} // end if
			if (orphan.compareTo(heap[largerChildIndex]) < 0)
			{
				heap[rootIndex] = heap[largerChildIndex];//Elements are swapped here
				rootIndex = largerChildIndex; 
				swapAmount++; //Append swapAmount
				leftChildIndex = 2 * rootIndex;
			}else
				done = true;
		} // end while
		heap[rootIndex] = orphan;
	} // end reheap

	//method: add(T newEntry)
	//purpose: Given a new element to add, this method will set the new element to the end and reheap
	public void add(T newEntry)
	{
		lastIndex++;
		ensureCapacity();
		int newIndex = lastIndex;
		int parentIndex = newIndex / 2;
		while ( (parentIndex > 0) && newEntry.compareTo(heap[parentIndex]) > 0)
		{
			heap[newIndex] = heap[parentIndex]; //Elements are swapped here
			newIndex = parentIndex;
			swapAmount++; //Append swapAmount
			parentIndex = newIndex / 2;
		} // end while
		heap[newIndex] = newEntry;
	} // end add

	//method: numberOfSwaps()
	//purpose: Returns the number of swaps that occur within the MaxHeap
	public int numberOfSwaps(){
		//		System.out.println(swapAmount);
		return swapAmount;
	}

	//method: removeMax()
	//purpose: Finds the largest of the MaxHeap and removes it. Reheaps once the max element is removed
	public T removeMax() {
		T root = null;
		if (!isEmpty())
		{
			root = heap[1]; // return value
			heap[1] = heap[lastIndex]; // form a semiheap
			lastIndex--; // decrease size
			reheap(1); // transform to a heap
		} // end if
		return root;
	}

	//method: printHeap()
	//purpose: Displays first 10 elements of the MaxHeap separated by commas
	public void printHeap(){
		for(int i = 1; i <= 10; i++){
			System.out.print(heap[i]);
			if(i != 10){
				System.out.print(",");;
			}
		}
		System.out.println("...");
	}
} // end MaxHeap