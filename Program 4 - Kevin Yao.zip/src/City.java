/***************************************************************
* file: City.java
* author: Kevin Yao
* class: CS 241 – Data Structures and Algorithms II
*
* assignment: program 4
* date last modified: 11/30/2017
*
* purpose: This is a simple class that stores the city's data fields.
*
****************************************************************/ 
public class City{

	private int number;
	private String cityCode;
	private String fullCityName;
	private String population;
	private String elevation;
	
	public City(){
		number = 0;
		cityCode = null;
		fullCityName = null;
		population = null;
		elevation = null;
	}
	
	public City (int num, String code, String name, String pop, String elev) {
		number = num;
		cityCode = code;
		fullCityName = name;
		population =  pop;
		elevation = elev;
	}

	public int returnNumber(){
		return number;
	}

	public String returnCode(){
		return cityCode;
	}

	public String returnName(){
		return fullCityName;
	}

	public String returnPopulation(){
		return population;
	}

	public String returnElevation(){
		return elevation;
	}

	public String toString(){
		return (number + " " + cityCode + " " + fullCityName + " "+ population + " " + elevation);
	}
}