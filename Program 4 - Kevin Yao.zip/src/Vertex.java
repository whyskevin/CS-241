/***************************************************************
* file: Vertex.java
* author: Kevin Yao
* class: CS 241 – Data Structures and Algorithms II
*
* assignment: program 4
* date last modified: 11/30/2017
*
* purpose: This program is modeled after the vertices in a graph. There is also a protected edge class which
* allows the different vertices to connect to each other
*
****************************************************************/ 
import java.util.Iterator;
import java.util.LinkedList;
import java.util.NoSuchElementException;

class Vertex<T> implements VertexInterface<T>
{
	private T label;
	private LinkedList<Edge> edgeList; // edges to
	// neighbors
	private boolean visited; // true if visited
	private VertexInterface<T> previousVertex; // on path to this vertex
	private double cost; // of path to this vertex

	//method: Vertex(T vertexLabel)
	//purpose: Default constructor that creates a new vertex and assigns a vertex label
	public Vertex(T vertexLabel)
	{
		label = vertexLabel;
		edgeList = new LinkedList<Edge>();
		visited = false;
		previousVertex = null;
		cost = 0;
	} // end constructor

	//method: connect(VertexInterface<T> endVertex, double edgeWeight)
	//purpose: Connects two vertices and adds an edge weight between the two
	public boolean connect(VertexInterface<T> endVertex, double edgeWeight)
	{
		boolean result = false;
		if (!this.equals(endVertex))
		{ // vertices are distinct
			Iterator<VertexInterface<T>> neighbors = this.getNeighborIterator();
			boolean duplicateEdge = false;
//			System.out.println(neighbors.hasNext());
			while (!duplicateEdge && neighbors.hasNext())
			{
				VertexInterface<T> nextNeighbor = neighbors.next();
				if (endVertex.equals(nextNeighbor))
					duplicateEdge = true;
			} // end while
			if (!duplicateEdge)
			{
				edgeList.add(new Edge(endVertex, edgeWeight));
				result = true;
			} // end if
		} // end if
		return result;
	} // end connect

	//method: connect(VertexInterface<T> endVertex)
	//purpose: Connects this vertex with another vertex with an edge weight of zero
	public boolean connect(VertexInterface<T> endVertex)
	{
		return connect(endVertex, 0);
	} // end connect

	//Inner class Edge
	protected class Edge
	{
		private VertexInterface<T> vertex; // end vertex
		private double weight;

		//method: Edge(VertexInterface<T> endVertex,  double edgeWeight)
		//purpose: Default constructor for an edge. Assigns the vertex on the connected end and the weight
		protected Edge(VertexInterface<T> endVertex, double edgeWeight)
		{
			vertex = endVertex;
			weight = edgeWeight;
		} // end constructor

		//method: getEndVertex()
		//purpose: Returns the vertex at the end
		protected VertexInterface<T> getEndVertex()
		{
			return vertex;
		} // end getEndVertex

		//method: getWeight()
		//purpose: Returns the weight of the edge 
		protected double getWeight()
		{
			return weight;
		} // end getWeight
	} // end Edge


	private class neighborIterator implements Iterator<VertexInterface<T>>
	{
		private Iterator<Edge> edges;
		private neighborIterator()
		{
			edges = edgeList.iterator();
		} // end default constructor
		public boolean hasNext()
		{
			return edges.hasNext();
		} // end hasNext
		public VertexInterface<T> next()
		{
			VertexInterface<T> nextNeighbor = null;
			if (edges.hasNext())
			{
				Edge edgeToNextNeighbor = edges.next();
				nextNeighbor = edgeToNextNeighbor.getEndVertex();
			}
			else
				throw new NoSuchElementException();
			return nextNeighbor;
		} // end nextpublic void remove()

		public void remove()
		{
			throw new UnsupportedOperationException();
		} // end remove
	} // end neighborIterator

	public T getLabel() {
		return label;
	}

	public void visit() {
		visited = true;
	}

	public void unvisit() {
		visited = false;
	}

	public boolean isVisited() {
		return visited;
	}

	public Iterator<VertexInterface<T>> getNeighborIterator() {
		return new neighborIterator();
	}


	public Iterator<Double> getWeightIterator() {
		LinkedList<Double> weightList = new LinkedList<Double>();
		Iterator<Edge> it = edgeList.iterator();
		while(it.hasNext()){
			weightList.add(it.next().getWeight());
		}
		return weightList.iterator();
	}


	public boolean hasNeighbor() {
		return !edgeList.isEmpty();
	}

	public VertexInterface<T> getUnvisitedNeighbor() {
		VertexInterface<T> result = null;
		Iterator<VertexInterface<T>> neighbors = getNeighborIterator();
		while ( (neighbors.hasNext() && (result == null) ))
		{
			VertexInterface<T> nextNeighbor = neighbors.next();
			if (!nextNeighbor.isVisited())
				result = nextNeighbor;
		} // end while
		return result;
	}


	//method: setPredecessor()
	//purpose: Sets the previousVertex private var to the predecessor vertex
	public void setPredecessor(VertexInterface<T> predecessor) {
		previousVertex = predecessor;
	}

	//method: getPredecessor()
	//purpose: Accessor method to return the previous vertex
	public VertexInterface<T> getPredecessor() {
		// TODO Auto-generated method stub
		return previousVertex;
	}

	public boolean hasPredecessor() {
		// TODO Auto-generated method stub
		return previousVertex == null;
	}

	public void setCost(double newCost) {
		cost = newCost;
	}

	public boolean remove(VertexInterface<T> removeMe){
		Iterator<Edge> it = edgeList.iterator();
		while(it.hasNext()){
			if(it.next().getEndVertex().equals(removeMe)){
				it.remove();
				return true;}
		}
		return false;
	}
	
	public double getCost() {
		return cost;
	}

	public boolean equals(Object other)
	{
		boolean result;
		if ((other == null) || (getClass() != other.getClass()))
			result = false;
		else
		{
			Vertex<T> otherVertex = (Vertex<T>)other;
			result = label.equals(otherVertex.label);
		} // end if
		return result;
	} // end equals
} // end Vertex