/***************************************************************
* file: Progam4.java
* author: Kevin Yao
* class: CS 241 – Data Structures and Algorithms II
*
* assignment: program 4
* date last modified: 11/30/2017
*
* purpose: Follows program specifications and presents a menu to the user to manipulate the city directed graph.
*
****************************************************************/ 
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.Stack;

public class Program4 {

	public static void main (String[] args) throws IOException{
		DirectedGraph<String> cityMap = new DirectedGraph<String> ();
		String [] cityCodes = new String[21]; //Array to hold city codes
		Map<String, City> cityData = new HashMap<String,City>(); //K: City Code - V: City Object

		BufferedReader cityReader = new BufferedReader(new FileReader("city.dat"));
		BufferedReader roadReader = new BufferedReader(new FileReader("road.dat"));

		String cityLine = cityReader.readLine();
		while(cityLine.length() != 0){
			//			System.out.println(cityLine);
			Scanner parse = new Scanner(cityLine);
			int number = parse.nextInt();
			String cityCode = parse.next();
			String cityName = parse.next();
			String population = parse.next();
			String elevation = parse.next();
			//			System.out.println(number + " - " + cityCode);
			City temp = new City(number,cityCode,cityName,population,elevation); //Creates a new City
			cityCodes[number] = cityCode; //Inputs into the array
			cityMap.addVertex(cityCode); //Adds city to the cityMap
			cityData.put(cityCode, temp);
			cityLine = cityReader.readLine();
		}

		String roadLine = roadReader.readLine();
		if(roadLine.length() == 0){
			System.out.println("Error");
		}

		while(roadReader.ready()){
			Scanner parse = new Scanner(roadLine);
			int vertexOne = parse.nextInt();
			int vertexTwo = parse.nextInt();
			int weight = parse.nextInt();
			//			System.out.println("Vertex One:" + cityCodes[vertexOne]);
			//			System.out.println("Vertex Two:" + cityCodes[vertexTwo]);
			cityMap.addEdge(cityCodes[vertexOne], cityCodes[vertexTwo], weight);
			roadLine = roadReader.readLine();
		}

		while(true){
			System.out.print("Command?");
			Scanner in = new Scanner(System.in);
			String command = in.next();

			int action = returnAction(command);
			switch(action){
			case 1:{
				Scanner getCityCode = new Scanner(System.in);
				System.out.print("City code:");
				String cityCode = getCityCode.nextLine();
				System.out.println(cityData.get(cityCode));
			}
			break;
			case 2:{
				Stack<String> stack = new Stack<String>();
				System.out.print("City codes: ");
				Scanner getCityCode = new Scanner(System.in);
				String input = getCityCode.nextLine();
				Scanner parse = new Scanner(input);
				String vertexOne = parse.next();
				String vertexTwo = parse.next();		
				System.out.println("The minimum distance between " + cityData.get(vertexOne).returnName()+
						" and " + cityData.get(vertexTwo).returnName()+
						" is " + cityMap.getCheapestPath(vertexOne, vertexTwo, stack));
				}
			break;
			case 3:{
				System.out.print("City codes and distance: ");
				Scanner getNewEdge = new Scanner(System.in);
				String p = getNewEdge.nextLine();
				Scanner parse = new Scanner(p);
				String vertexOne = parse.next();
				String vertexTwo = parse.next();
				int weight = parse.nextInt();
				if(cityMap.addEdge(vertexOne, vertexTwo, weight)){
					System.out.println("You have inserted a road from " +
							cityData.get(vertexOne).returnName() + 
							" to " + cityData.get(vertexTwo).returnName() +
							" with a distance of " + weight);
				}else{
					System.out.println("Warning: Cities already exist or an road already exists!");
				}
			}
			break;
			case 4:{
				System.out.print("City codes:");
				Scanner getCityCodes = new Scanner(System.in);
				String input = getCityCodes.nextLine();
				Scanner parse = new Scanner(input);
				String vertexOne = parse.next();
				String vertexTwo = parse.next();
				if(!cityMap.removeEdge(vertexOne, vertexTwo)){
					System.out.println("The road from " + cityData.get(vertexOne).returnName() 
							+ " to " + cityData.get(vertexTwo).returnName() + " doesn't exist.");
				}
			}
			break;
			case 5:
				displayHelp();
				break;
			case 6:
				System.out.println("Exiting program...");
				return;
			default:
			}
		}
	}

	public static void displayHelp(){
		System.out.println( "Q Query the city information by entering the city code.\n"+
				"D Find the minimum distance between two cities.\n"+
				"I Insert a road by entering two city codes and distance.\n"+
				"R Remove an existing road by entering two city codes.\n"+
				"H Display this message.\n"+
				"E Exit.");
	}

	public static int returnAction(String command){
		char firstLetter = command.charAt(0);
		if(firstLetter == 'Q' || firstLetter == 'q'){
			return 1;
		}else if(firstLetter == 'D'){
			return 2;
		}else if(firstLetter == 'I'){
			return 3;
		}else if(firstLetter == 'R'){
			return 4;
		}else if(firstLetter == 'H'){
			return 5;
		}else if(firstLetter == 'E'){
			return 6;
		}
		return 0;
	}

}
