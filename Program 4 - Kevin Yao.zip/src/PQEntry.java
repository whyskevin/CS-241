/***************************************************************
* file: PQEntry.java
* author: Kevin Yao
* class: CS 241 – Data Structures and Algorithms II
*
* assignment: program 4
* date last modified: 11/30/2017
*
* purpose: Object used for the priority queue in the cheapest path algorithm.
*
****************************************************************/ 
public class PQEntry<T> {

	private VertexInterface<T> vertex;
	private VertexInterface<T> predecessor;
	private double weight;
	
	public PQEntry(){
		vertex = null;
		predecessor = null;
		weight = 0;
	}

	public PQEntry(VertexInterface<T> next, double wt, VertexInterface<T> pred ){
		vertex = next;
		predecessor = pred;
		weight = wt;
	}
	
	public VertexInterface<T> returnFront(){
		return vertex;
	}
	
	public VertexInterface<T> returnPred(){
		return predecessor;
	}
	
	public double returnCost(){
		return weight;
	}
	
}
