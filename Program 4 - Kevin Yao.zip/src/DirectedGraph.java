/***************************************************************
* file: DirectedGraph.java
* author: Kevin Yao
* class: CS 241 – Data Structures and Algorithms II
*
* assignment: program 4
* date last modified: 11/30/2017
*
* purpose: This class is modeling a directed graph. It holds a Map of keys and vertices to efficiently link
* edges between vertices and return the vertices given a key.
*
****************************************************************/ 
import java.util.Dictionary;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Set;
import java.util.Stack;


public class DirectedGraph<T>
{
	private Map<T, VertexInterface<T>> vertices;
	private int edgeCount;

	//method: DirectedGraph()
	//purpose: Default constructor for DirectedGraph. Creates a Map of <Key, Vertices>
	public DirectedGraph()
	{
		vertices = new HashMap<T, VertexInterface<T>>();
		edgeCount = 0;
	} // end default constructor

	//method: addVertex(T vertexLabel)
	//purpose: Given a label, the directed graph adds a vertex to the Map
	public boolean addVertex(T vertexLabel)
	{
		VertexInterface<T> isDuplicate =
				vertices.put(vertexLabel, new Vertex(vertexLabel));
		return isDuplicate == null; // was add to dictionary successful?
	} // end addVertex

	//method: addEdge()
	//purpose: Adds a weighted edge between two vertices 
	public boolean addEdge(T begin, T end, double edgeWeight)
	{
		boolean result = false;
		VertexInterface<T> beginVertex = vertices.get(begin);
		if(beginVertex == null){
			System.out.println("wtf");
		}
		VertexInterface<T> endVertex = vertices.get(end);
		if ( (beginVertex != null) && (endVertex != null) )
			result = beginVertex.connect(endVertex, edgeWeight);
		if (result)
			edgeCount++;
		return result;
	} // end addEdge

	//method: addEdge()
	//purpose: Boolean method that returns true if the new edge between two vertices is added succesfully
	public boolean addEdge(T begin, T end)
	{
		return addEdge(begin, end, 0);
	} // end addEdge

	//method: removeEdge()
	//purpose: Removes an edge between the two given vertices
	public boolean removeEdge(T begin, T end){
		if(hasEdge(begin, end)){ //If there's an edge
			VertexInterface<T> beginningVertex = vertices.get(begin);
			VertexInterface<T> endVertex = vertices.get(end);
			return beginningVertex.remove(endVertex);
		}else{
			return false;
		}
	}

	//method: hasEdge(T begin, T end)
	//purpose: Checks if 
	public boolean hasEdge(T begin, T end)
	{
		boolean found = false;
		VertexInterface<T> beginVertex = vertices.get(begin);
		VertexInterface<T> endVertex = vertices.get(end);
		if ( (beginVertex != null) && (endVertex != null) )
		{
			Iterator<VertexInterface<T>> neighbors =
					beginVertex.getNeighborIterator();
			while (!found && neighbors.hasNext())
			{
				VertexInterface<T> nextNeighbor = neighbors.next();
				if (endVertex.equals(nextNeighbor))
					found = true;
			} // end while
		} // end if
		return found;
	} // end hasEdge

	//method: isEmpty()
	//purpose: Returns true if the graph is empty
	public boolean isEmpty()
	{
		return vertices.isEmpty();
	} // end isEmpty

	//method: clear()
	//purpose: Deallocates all vertices in the graph
	public void clear()
	{
		vertices.clear();
		edgeCount = 0;
	} // end clear

	//method: getNumberOfVertices()
	//purpose: Returns the size of the map
	public int getNumberOfVertices()
	{
		return vertices.size();
	} // end getNumberOfVertices

	//
	public int getNumberOfEdges()
	{
		return edgeCount;
	} // end getNumberOfEdges

	protected void resetVertices()
	{
		Set setOfVertices = vertices.entrySet();
		Iterator<VertexInterface<T>> vertexIterator = setOfVertices.iterator();
		while (vertexIterator.hasNext())
		{
			VertexInterface<T> nextVertex = vertexIterator.next();
			nextVertex.unvisit();
			nextVertex.setCost(0);
			nextVertex.setPredecessor(null);
		} // end while
	} // end resetVertices

	public double getCheapestPath(T begin, T end, Stack<T> path){
		boolean done = false;
		PriorityQueue<PQEntry<T>> pq = new PriorityQueue<PQEntry<T>>();
		pq.add(new PQEntry<T>(vertices.get(begin), 0, null));
		while(!done && !pq.isEmpty()){
			PQEntry<T> frontEntry = pq.remove();
			VertexInterface<T> frontVertex = frontEntry.returnFront();

			if(!frontVertex.isVisited()){
				frontVertex.visit();
				frontVertex.setCost(frontEntry.returnCost());
				frontVertex.setPredecessor(frontEntry.returnPred());
				if(frontVertex.equals(vertices.get(end)))
				{
					done = true;	
				}else{
					while(frontVertex.hasNeighbor()){
						VertexInterface<T> nextNeighbor = frontVertex.getUnvisitedNeighbor();
						nextNeighbor.setCost(frontVertex.getCost());
						if(!frontVertex.getUnvisitedNeighbor().isVisited()){
							double nextCost = nextNeighbor.getCost() + frontVertex.getCost();
							pq.add(new PQEntry<T> (nextNeighbor, nextCost, frontVertex));
						}

					}
				}

			}
		}
		double pathCost = pq.remove().returnCost();
		path.push(end);
		VertexInterface<T> vertex = vertices.get(end);
		while(vertex.hasPredecessor()){
			vertex = vertex.getPredecessor();
			path.push(vertex.getLabel());
		}
		return pq.remove().returnCost();
	}

	public int getShortestPath(T begin, T end, Stack<T> path)
	{
		resetVertices();
		boolean done = false;
		Queue<VertexInterface<T>> vertexQueue =
				new LinkedList<VertexInterface<T>>();
		VertexInterface<T> originVertex = vertices.get(begin);
		VertexInterface<T> endVertex = vertices.get(end);
		originVertex.visit();
		// Assertion: resetVertices() has executed setCost(0)
		// and setPredecessor(null) for originVertex
		vertexQueue.add(originVertex);
		while (!done && !vertexQueue.isEmpty())
		{
			VertexInterface<T> frontVertex = vertexQueue.remove();
			Iterator<VertexInterface<T>> neighbors =
					frontVertex.getNeighborIterator();
			while (!done && neighbors.hasNext())
			{
				VertexInterface<T> nextNeighbor = neighbors.next();
				if (!nextNeighbor.isVisited())
				{
					nextNeighbor.visit();
					nextNeighbor.setCost(1 + frontVertex.getCost());
					nextNeighbor.setPredecessor(frontVertex);
					vertexQueue.remove(nextNeighbor);
				} // end if
				if (nextNeighbor.equals(endVertex))
					done = true;
			} // end while
		} // end while
		// traversal ends; construct shortest path
		int pathLength = (int)endVertex.getCost();
		path.push(endVertex.getLabel());
		VertexInterface<T> vertex = endVertex;
		while (vertex.hasPredecessor())
		{
			vertex = vertex.getPredecessor();
			path.push(vertex.getLabel());
		} // end while
		return pathLength;
	} // end getShortestPath


} // end DirectedGraph