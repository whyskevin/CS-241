import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;


public class TestGraph {

	public static void main (String[] args) throws IOException{
	
//		DirectedGraph
		Vertex<String> anaheim = new Vertex<String>("AN");
		Vertex<String> bosstown = new Vertex<String>("BO");
		
		anaheim.connect(bosstown,100);
		
	}	
}
